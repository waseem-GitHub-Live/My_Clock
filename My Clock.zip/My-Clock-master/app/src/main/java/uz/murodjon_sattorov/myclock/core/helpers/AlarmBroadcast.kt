package uz.murodjon_sattorov.myclock.core.helpers

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.PowerManager
import android.util.Log
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import uz.murodjon_sattorov.myclock.R
import uz.murodjon_sattorov.myclock.receivers.AlarmReceiver
import java.util.*


class AlarmBroadcast {

    private var calendar: Calendar? = null
    private var alarmManager: AlarmManager? = null
    private var pendingIntent: PendingIntent? = null
    private val CHANNEL_TIME_FINISHED = "time_finished"
    fun getDismissIntent(notificationId: Int, context: Context): PendingIntent? {
            val intent = Intent()
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            intent.putExtra(CHANNEL_TIME_FINISHED, notificationId)
            return PendingIntent.getActivity(
                context,
                0,
                intent,
                PendingIntent.FLAG_CANCEL_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
    }
    fun setAlarm(context: Context, hour: Int, minutes: Int, requestCode: Int) {
        Log.d("SSS", "setAlarm1: ")
        alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

        val intent = Intent(context, AlarmReceiver::class.java)

        pendingIntent = PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_IMMUTABLE
        )


        calendar = Calendar.getInstance()
        calendar!!.set(Calendar.HOUR_OF_DAY, hour)
        calendar!!.set(Calendar.MINUTE, minutes)
        calendar!!.set(Calendar.SECOND, 0)
        calendar!!.set(Calendar.MILLISECOND, 0)

        Log.d("SSS", "setAlarm2: ")

        alarmManager!!.setRepeating(
            AlarmManager.RTC_WAKEUP,
            calendar!!.timeInMillis,
            AlarmManager.INTERVAL_DAY,
            pendingIntent
        )

        alarmManager!!.setExact(AlarmManager.RTC_WAKEUP, calendar!!.timeInMillis, pendingIntent)

        Toast.makeText(context, "Alarm set successfully", Toast.LENGTH_SHORT).show()
    }

    fun cancelAlarm(context: Context, requestCode: Int) {
        val intent = Intent(context, AlarmReceiver::class.java)

        pendingIntent = PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_IMMUTABLE
        )
        if (alarmManager == null) {
            alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        }

        alarmManager?.cancel(pendingIntent)
        Toast.makeText(context, "Alarm canceled", Toast.LENGTH_SHORT).show()
    }

    fun createNotificationChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name: CharSequence = "Alarm"
            val description = "Alarm done"

            val importance = NotificationManager.IMPORTANCE_HIGH
            val channel = NotificationChannel("alarm_channel", name, importance)
            channel.description = description

            val notificationManager = context.getSystemService(NotificationManager::class.java)
            notificationManager.createNotificationChannel(channel)

        }
    }

    fun showNotification(context: Context, title: String, content: String) {
        val notificationBuilder = NotificationCompat.Builder(context, "alarm_channel")
            .setSmallIcon(R.drawable.ic_round_access_alarm_24)
            .setContentTitle(title)
            .setContentText(content)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)

        val notificationManager = NotificationManagerCompat.from(context)
        notificationManager.notify(1, notificationBuilder.build())
    }
}